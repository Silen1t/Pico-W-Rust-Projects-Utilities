#![no_std]
#![no_main]

use defmt::*;
use embassy_executor::Spawner;
use embassy_rp::gpio;
use embassy_time::Timer;
use gpio::{ Level, Output };
use ::{ defmt_rtt as _, panic_probe as _ };

#[embassy_executor::main]
async fn main(_spawner: Spawner) {
    let p = embassy_rp::init(Default::default());
    let mut led = Output::new(p.PIN_16, Level::Low);

    loop {
        info!("led on!");
        led.toggle();
        Timer::after_secs(1).await;

        info!("led off!");
        led.toggle();
        Timer::after_secs(1).await;
    }
}
